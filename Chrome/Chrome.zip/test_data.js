﻿[
    {
        Name: "PMVM-2435",
        Team: "Dealer",
        State: "Released",
        Enabled: true
    },
    {
        Name: "CLLayout",
        Team: "Dealer",
        State: "Under Test",
        Enabled: true
    },
    {
        Name: "PMVM-2557 - Responsive List",
        Team: "ASM Enduser",
        State: "In Development",
        Enabled: false
    },
    {
        Name: "GuidedTourButton",
        Team: "Dealer",
        State: "Under Test",
        Enabled: true
    },
    {
        Name: "PMVM-2332 - Improving SEO for Lists/Details",
        Team: "ASM Garage",
        State: "In Development",
        Enabled: false
    },
    {
        Name: "HTML5ImageUpload",
        Team: "Dealer",
        State: "In Development",
        Enabled: false
    },
    {
        Name: "AverageQuality",
        Team: "Dealer",
        State: "In Development",
        Enabled: false
    },
    {
        Name: "PMVM1078",
        Team: "Dealer",
        State: "Released",
        Enabled: true
    },
    {
        Name: "New Audacon Import",
        Team: "ASM Enduser",
        State: "In Development",
        Enabled: false
    },
    {
        Name: "PMVM-2496-AdjustClassifiedListToggle",
        Team: "Dealer",
        State: "In Development",
        Enabled: false
    },
    {
        Name: "AveragePriceNew",
        Team: "Dealer",
        State: "Under Test",
        Enabled: true
    },
    {
        Name: "PMVM-2407",
        Team: "Dealer",
        State: "Under Test",
        Enabled: true
    }
];