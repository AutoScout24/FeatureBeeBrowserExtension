﻿FeatureBeeToggleInitiator = new function() {

    this.initKeyboardEvent = function(initDelegate) {
        FeatureBeeTogglesExtensionStorage.retrieveTogglePersonalConfig(initDelegate)
        {
            
        }
    };
}