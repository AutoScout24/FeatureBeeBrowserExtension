﻿CommunicationInterface.retrieveToggles(function (toggles) {
    FeatureBeeToggleExtensionController.popup(toggles);
    console.log("received toggles");
    console.log(toggles);
});

